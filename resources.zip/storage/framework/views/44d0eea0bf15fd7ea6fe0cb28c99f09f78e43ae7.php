<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('title'); ?>
    <?php echo $__env->yieldContent('seo'); ?>
    <link rel="shortcut icon" href="<?php echo e(isset($system->favicon)?asset($system->favicon):''); ?>">

    <!-- Bootstrap Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/css/vendor/bootstrap.min.css')); ?>" />
    <!-- Font-Awesome Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/css/vendor/fontawesome-all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/css/vendor/nav.css')); ?>">
    <!-- Owl-Carousel Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/css/vendor/owl.carousel.min.css')); ?>" />
    <!-- Owl-Carousel Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/css/vendor/swiper.css')); ?>" />
    <!-- Animate Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/css/vendor/animate.css')); ?>" />
    <!-- magnific-popup Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/css/vendor/magnific-popup.css')); ?>" />
    <!-- Jquery Ui Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/css/vendor/jquery-ui.min.css')); ?>" />
    <!-- Style Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/css/style.css')); ?>" />
    <!-- Responsive Css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/css/responsive.css')); ?>" />
    <?php echo $__env->yieldContent('style'); ?> 

</head>
<body><?php /**PATH C:\xampp7.3\htdocs\textile\resources\views/frontEnd/include/header.blade.php ENDPATH**/ ?>