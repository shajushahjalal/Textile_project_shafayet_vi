<?php $__env->startSection('title'); ?>
<title><?php echo e($data->menuName .' || '); ?>  <?php echo e($system->titleName); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('seo'); ?>
<?php echo isset($seo->id)?$seo->seo:''; ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mainPart'); ?>

    <!--== Page Title Area Start ==-->
    <section class="page-title-area overlay overlay--2" style="padding:20px 0px 0px 0px; ">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 m-auto text-center">
                    <div class="page-title-content">
                        <!--== Page Title Area End ==-->
                        <nav class="text-center" aria-label="breadcrumb">
                            <ol class="breadcrumb" style="display: inline-flex;">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fas fa-home"></i> Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo e($data->menuName); ?></li>
                            </ol>
                        </nav>                 
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- about-details start  -->
    <div class=" container-fluid" style="background:#eee;color:#555;">
        <div class="row">
            <div class="col-10 offset-1 mt-40 mb-40">
                <div class="text-justify">
                    <?php if(file_exists($data->image)): ?>
                    <img src="<?php echo e(asset($data->image)); ?>" class=" img-fluid mb-20" style="max-height:400px;">
                    <?php endif; ?>
                    <?php echo $data->content; ?>

                </div>  
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\textile\resources\views/frontEnd/other/viewFooterPage.blade.php ENDPATH**/ ?>