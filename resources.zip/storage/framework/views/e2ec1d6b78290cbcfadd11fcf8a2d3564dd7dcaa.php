<?php $__env->startSection('title'); ?>
    <?php if(isset($product) && !empty($product->pageTitle) ): ?>
    <title> <?php echo e($product->pageTitle); ?> </title>
    <?php else: ?>
        <title> <?php echo e($title); ?> || <?php echo e($system->titleName); ?> </title>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('seo'); ?>
    <?php if(isset($seo_data) && !empty($seo_data->metaTag) ): ?>
        <meta name="keywords" content="<?php echo e($seo_data->metaTag); ?>" >
        <meta name="description" content="<?php echo e($seo_data->metaDescription); ?>" >
    <?php else: ?>
    <?php echo isset($seo->id)?$seo->seo:''; ?> 
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mainPart'); ?>
<!--== Page Title Area Start ==-->
<section class="page-title-area overlay overlay--2" style="padding:20px 0px 0px 0px; ">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 m-auto text-center">
                <div class="page-title-content">
                    <h1 class="h2">What We Do</h1> 
                    <!--== Page Title Area End ==-->
                    <nav class="text-center">
                        <ol class="breadcrumb" style="display: inline-flex;">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fas fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(isset($seo_data->categoryName)?$seo_data->categoryName:$seo_data->subCategoryName); ?> </li>
                        </ol>
                    </nav>                  
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Product Section -->
<section class="mb-30">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12">
                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-12 mt-3 mb-3 text-black">
                                <span class="grid-show btn btn-default"><i class="fas fa-th-large"></i></span>
                                <span class="list-show btn btn-default"><i class="fas fa-list"></i></span>
                                <hr>
                            </div>
                        </div>
                        <div class="row product-display-gird">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mt-2 col-12 col-sm-6 col-md-6 col-lg-4 col-xl-3">
                                <div>
                                    <a href="<?php echo e(url('view/product/'.$product->productName)); ?>">
                                        <img src="<?php echo e(asset($product->image)); ?>" class=" img-fluid">
                                    </a>
                                </div>
                                <div class="text-center product-overlap-icons">
                                    <a href="#"> <i class="far fa-heart fa-lg"></i> </a> &nbsp; | &nbsp; 
                                    <a href="<?php echo e(url('view/product/'.$product->productName)); ?>" title="view details"> <i class="far fa-eye fa-lg"></i> </a>
                                </div>
                                <div class="text-center">
                                    <a href="<?php echo e(url('view/product/'.$product->productName)); ?>"><?php echo e($product->productName); ?> </a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="row product-display-list d-none">
                            <div class="mt-2 col-12">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row mt-2">
                                    <div class="col-6">
                                        <a href="<?php echo e(url('view/product/'.$product->productName)); ?>">
                                            <img src="<?php echo e(asset($product->image)); ?>" class=" img-fluid">
                                        </a>
                                    </div>
                                    <div class="col-6">
                                        <a href="<?php echo e(url('view/product/'.$product->productName)); ?>">
                                            <?php echo e($product->productName); ?>

                                        </a><br>
                                        <a href="<?php echo e(url('view/product/'.$product->productName)); ?>">
                                            <i class="far fa-eye fa-lg"></i> View Details
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>                            
                        </div>
                    </div>

                    <!-- Right Side Bar -->
                    <div class="col-md-4">
                        <div class="row">
                            <div class="col-12 mt-4 mb-4 text-black">
                                <h4 class=" text-uppercase">Category</h4>
                                <hr/>
                            </div>
                            <div class="col-12 text-black">
                                <nav class="nav flex-column">  
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($category->haveSubCategory == 1): ?>
                                        <?php $__currentLoopData = $category->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="nav-link" href="<?php echo e(url('view-category/'.$category->categoryName.'/'.$subCategory->subCategoryName)); ?>"> <?php echo e($subCategory->subCategoryName); ?> </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <a class="nav-link" href="<?php echo e(url('view-category/'.$category->categoryName)); ?>""><?php echo e($category->categoryName); ?></a>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </nav>                                
                            </div>
                        </div> 
                        <div class="row">
                            <div class="col-12 mt-4 mb-4 text-black">
                                <h4 class=" text-uppercase">Recent Uploaded</h4>
                                <hr/>
                            </div>
                        </div>
                        <div class="col-12 text-black">
                            <?php $__currentLoopData = $recentProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row mt-2">                                
                                <div class="col-4">
                                    <a href="<?php echo e(url('view/product/'.$product->productName)); ?>"><img src="<?php echo e(asset($product->image)); ?>" class=" img-fluid"></a>
                                </div>
                                <div class="col-8">
                                    <a href="<?php echo e(url('view/product/'.$product->productName)); ?>" ><?php echo e($product->productName); ?></a>
                                </div>                               
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(function(){
        $('.list-show').on('click',function(){
            $('.product-display-gird').addClass('d-none');
            $('.product-display-list').removeClass('d-none');
        });
        $('.grid-show').on('click',function(){
            $('.product-display-gird').removeClass('d-none');
            $('.product-display-list').addClass('d-none');
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\textile\resources\views/frontEnd/product/viewProducts.blade.php ENDPATH**/ ?>