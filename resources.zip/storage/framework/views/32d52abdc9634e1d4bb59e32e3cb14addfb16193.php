
    <!-- preloader -->
    <div class="preloader">
        <div class="loader">
            <div class="loader--dot"></div>
            <div class="loader--dot"></div>
            <div class="loader--dot"></div>
            <div class="loader--dot"></div>
            <div class="loader--dot"></div>
            <div class="loader--dot"></div>
            <div class="loader--text"></div>
        </div>
    </div>
    <!-- preloader -->

    <!-- main-container -->
    <div class="main-container">
        <!-- header start -->
    
      <!-- Header -->
        <div class="navik-header header-opacity header-shadow">
            <div class="container">

                <!-- Navik header -->
                <div class="navik-header-container">
                    
                    <!--Logo-->
                    <div class="logo" data-mobile-logo="<?php echo e(asset($system->logo)); ?>" data-sticky-logo="<?php echo e(asset($system->logo)); ?>">
                        <a href="<?php echo e(url('/')); ?>"> <img class="img-fluid"  src="<?php echo e(asset($system->logo)); ?>" alt="Logo"> </a>
                    </div>
                    
                    <!-- Burger menu -->
                    <div class="burger-menu">
                        <div class="line-menu line-half first-line"></div>
                        <div class="line-menu"></div>
                        <div class="line-menu line-half last-line"></div>
                    </div>

                    <!--Navigation menu-->
                    <nav class="navik-menu separate-line submenu-top-border submenu-scale">
                        <ul class="list-unstyled">
                            <li class="current-menu"><a href="<?php echo e(url('/')); ?>"> Home </a></li>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category->haveSubCategory == 1): ?>
                                <li class=""><a href="<?php echo e(url('view-category/'.$category->categoryName)); ?>"> <?php echo e($category->categoryName); ?> </a>
                                    <ul class="list-unstyled" >
                                    <?php $__currentLoopData = $category->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(url('view-category/'.$category->categoryName.'/'.$subCategory->subCategoryName)); ?>"> <?php echo e($subCategory->subCategoryName); ?> </a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                                <?php else: ?>
                                    <li><a href="<?php echo e(url('view-category/'.$category->categoryName)); ?>"> <?php echo e($category->categoryName); ?> </a></li>
                                <?php endif; ?>   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url('galary')); ?>"> Gallery </a></li>
                            <li><a href="#about-us" class="smoothScroll" >About Us</a></li>
                            <li><a href="#portfolio" class="smoothScroll" >Portfolio</a></li>
                            <li><a href="<?php echo e(url('contact-us')); ?>">Contact Us</a></li>
                        </ul>
                    </nav>

                </div>

            </div>
        </div><?php /**PATH C:\xampp7.3\htdocs\textile\resources\views/frontEnd/include/menu.blade.php ENDPATH**/ ?>