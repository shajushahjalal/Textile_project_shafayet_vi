<html>
    <head></head>
    <body>
        <div style="background: #ddd;line-height:1.3;color:#444; width:60%;font-size:17px;margin: 0px auto;padding:30px;border-radius:7px;">
            {!! $messagebody !!}
        </div>
    </body>
</html>