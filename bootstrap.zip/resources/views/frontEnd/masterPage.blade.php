@include('frontEnd.include.header')
@include('frontEnd.include.menu')
@yield('mainPart')
@include('frontEnd.include.footer')