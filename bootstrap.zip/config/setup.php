 <?php 

/* 
* Application Setup Done 
* @Developer: Sm Shahjalal Shaju 
 * Email: shajushahjalal@gmail.com 
*/
return[ 
 	'version' => '1.0.7',
];