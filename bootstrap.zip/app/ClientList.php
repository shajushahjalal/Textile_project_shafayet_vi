<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClientList extends Model
{
    //
}
