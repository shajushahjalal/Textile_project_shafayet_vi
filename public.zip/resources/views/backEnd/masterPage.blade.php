@include('backEnd.includes.header')
@include('backEnd.includes.menu')
@yield('mainPart')
@include('backEnd.includes.footer')

